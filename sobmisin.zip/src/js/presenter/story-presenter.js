import StoryApiSource from "../data/story-api-source.js";
import MapUtils from "../utils/map.js";
import CameraUtils from "../utils/camera.js";
import AuthModel from "../model/auth-model.js";
import Swal from "sweetalert2";

class StoryPresenter {
  constructor({ mainView, homePageView, addStoryPageView, detailPageView }) {
    this._mainView = mainView;
    this._homePageView = homePageView;
    this._addStoryPageView = addStoryPageView;
    this._detailPageView = detailPageView;

    this._selectedCoords = null;
    this._capturedImageBlob = null;
  }

  _cleanupAddStoryResourcesOnly() {
    console.log("Cleaning up add story specific resources (camera, blob)...");
    CameraUtils.stopStream();
    if (this._capturedImageBlob) {
      URL.revokeObjectURL(this._capturedImageBlob);
      this._capturedImageBlob = null;
    }
    this._selectedCoords = null;
  }

  cleanupPageResources() {
    console.log("Cleaning up all page resources...");
    this._cleanupAddStoryResourcesOnly();
    
    if (MapUtils && typeof MapUtils.cleanupAllMaps === 'function') {
      MapUtils.cleanupAllMaps();
    } else {
      console.warn("MapUtils.cleanupAllMaps not available. Make sure you've updated MapUtils.");
    }
    
    console.log("Page resource cleanup finished.");
  }

  async displayHomePage() {
    this.cleanupPageResources();
    try {
      const response = await StoryApiSource.getAllStories({ location: 1 });
      if (!response.error) {
        this._mainView.renderPage(
          () => this._homePageView.render(response.listStory),
          () => this._setupHomeFeatures(response.listStory)
        );
      } else {
        this._mainView.showError(response.message || "Failed to fetch stories.");
      }
    } catch (error) {
      console.error("Error fetching stories:", error);
      if (
        error.message.includes("token") ||
        error.message.includes("logged in")
      ) {
        AuthModel.clearCredentials();
        window.location.hash = "#/login";
        this._mainView.showError("Session expired. Please log in again.");
      } else {
        this._mainView.showError(error.message || "Could not connect to the server.");
      }
    }
  }

  _setupHomeFeatures(stories) {
    console.log("Setting up home features...");
    const mapContainer = document.getElementById("storiesMap");

    if (mapContainer) {
      try {
        console.log("Initializing home map...");
        const homeMap = MapUtils.initMap("storiesMap");
        const storiesWithLocation = stories.filter((story) => story.lat && story.lon);

        if (storiesWithLocation.length > 0) {
          MapUtils.addMarkers(homeMap, storiesWithLocation);
          try {
            const bounds = L.latLngBounds(storiesWithLocation.map((s) => [s.lat, s.lon]));
            homeMap.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
          } catch (boundsError) {
            console.error("Error fitting map bounds:", boundsError);
            homeMap.setView(MapUtils._defaultCenter, MapUtils._defaultZoom);
          }
        } else {
          console.log("No stories with location data found for home map.");
          mapContainer.innerHTML = '<p style="text-align: center; padding: 20px;">No locations to display.</p>';
        }
      } catch (error) {
        console.error("Failed to initialize home map:", error);
        mapContainer.innerHTML = `<p>Error loading map: ${error.message}</p>`;
      }
    } else {
      console.warn("#storiesMap container not found during setup");
    }
  }

  displayAddStoryPage() {
    this.cleanupPageResources();
    this._mainView.renderPage(
      () => this._addStoryPageView.render(),
      () => this._setupAddStoryFeatures()
    );
  }

  _setupAddStoryFeatures() {
    console.log("Setting up add story features...");
    const form = document.getElementById("addStoryForm");
    const cameraPreview = document.getElementById("cameraPreview");
    const captureButton = document.getElementById("captureButton");
    const retakeButton = document.getElementById("retakeButton");
    const imagePreview = document.getElementById("imagePreview");
    const mapContainer = document.getElementById("locationPickerMap");
    const descriptionInput = document.getElementById("description");
    const useLocationCheckbox = document.getElementById("useLocation");
    const mapSection = document.getElementById("mapSection");
    const cameraErrorDiv = document.getElementById("cameraError");
    const coordDisplay = document.getElementById("selectedCoords");

    if (
      !form || !cameraPreview || !captureButton || !retakeButton || !imagePreview ||
      !mapContainer || !descriptionInput || !useLocationCheckbox || !mapSection ||
      !cameraErrorDiv || !coordDisplay
    ) {
      console.error("One or more elements missing in add story page.");
      this._mainView.showError("Failed to load add story page components.");
      return;
    }

    const startCameraAndHandleError = () => {
      CameraUtils.startCamera(cameraPreview)
        .then(() => {
          cameraErrorDiv.style.display = "none";
          captureButton.style.display = "inline-block";
          retakeButton.style.display = "none";
          imagePreview.style.display = "none";
          cameraPreview.style.display = "block";
        })
        .catch((err) => {
          console.error("Failed to start camera:", err);
          cameraErrorDiv.textContent = `Could not access camera: ${err.message}. Please grant permission.`;
          cameraErrorDiv.style.display = "block";
          captureButton.style.display = "none";
        });
    };
    startCameraAndHandleError();

    captureButton.onclick = async () => {
      try {
        this._capturedImageBlob = await CameraUtils.captureImageBlob(cameraPreview);
        if (this._capturedImageBlob) {
          imagePreview.src = URL.createObjectURL(this._capturedImageBlob);
          imagePreview.style.display = "block";
          cameraPreview.style.display = "none";
          captureButton.style.display = "none";
          retakeButton.style.display = "inline-block";
          CameraUtils.stopStream();
        }
      } catch (error) {
        console.error("Failed to capture image:", error);
        Swal.fire("Error", "Error capturing image.", "error");
      }
    };

    retakeButton.onclick = () => {
      imagePreview.style.display = "none";
      imagePreview.src = "";
      if (this._capturedImageBlob) {
        URL.revokeObjectURL(this._capturedImageBlob);
        this._capturedImageBlob = null;
      }
      cameraPreview.style.display = "block";
      captureButton.style.display = "inline-block";
      retakeButton.style.display = "none";
      startCameraAndHandleError();
    };

    const initMapForPicking = () => {
      try {
        console.log("Initializing location picker map...");
        const locationMap = MapUtils.initLocationPickerMap(
          "locationPickerMap",
          (coords) => {
            this._selectedCoords = coords;
            console.log("Location selected:", coords);
            if (coordDisplay) {
              coordDisplay.textContent = `Lat: ${coords.lat.toFixed(5)}, Lng: ${coords.lng.toFixed(5)}`;
            }
          }
        );
        setTimeout(() => {
          if (locationMap) locationMap.invalidateSize();
        }, 150);
      } catch (error) {
        console.error("Failed to initialize location picker map:", error);
        const actualMapDiv = document.getElementById('locationPickerMap');
        if (actualMapDiv) actualMapDiv.innerHTML = `<p>Error loading map: ${error.message}</p>`;
      }
    };

    useLocationCheckbox.onchange = (event) => {
      if (event.target.checked) {
        mapSection.style.display = "block";
        initMapForPicking();
      } else {
        mapSection.style.display = "none";
        this._selectedCoords = null;
        if (coordDisplay) {
          coordDisplay.textContent = "Location not set";
        }
        MapUtils.cleanupMap("locationPickerMap");
      }
    };
    
    mapSection.style.display = useLocationCheckbox.checked ? "block" : "none";
    if (coordDisplay) coordDisplay.textContent = "Location not set";
    
    if (useLocationCheckbox.checked) {
      initMapForPicking();
    }

    form.onsubmit = async (event) => {
      event.preventDefault();
      const description = descriptionInput.value.trim();
      const useLocation = useLocationCheckbox.checked;

      if (!description) { return; }
      if (!this._capturedImageBlob) { return; }
      if (useLocation && !this._selectedCoords) { return; }
      if (this._capturedImageBlob.size > 1 * 1024 * 1024) { return; }

      const lat = useLocation ? this._selectedCoords.lat : null;
      const lon = useLocation ? this._selectedCoords.lng : null;

      const submitButton = form.querySelector('button[type="submit"]');
      submitButton.disabled = true;
      submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';

      Swal.fire({ });

      try {
        const useGuest = !AuthModel.isLoggedIn();
        const storyData = { description, photo: this._capturedImageBlob, lat, lon };
        let response;

        if (useGuest) { response = await StoryApiSource.addNewStoryGuest(storyData); }
        else { response = await StoryApiSource.addNewStory(storyData); }

        Swal.close();

        if (!response.error) {
          Swal.fire("Success!", "Story added successfully!", "success");
          window.location.hash = "#/home";
        } else {
          Swal.fire("Error!", response.message || "Failed to add story.", "error");
          submitButton.disabled = false;
          submitButton.innerHTML = '<i class="fas fa-plus"></i> Add Story';
        }
      } catch (error) {
        Swal.close();
        console.error("Error adding story:", error);
        Swal.fire("Error!", error.message || "An error occurred while adding the story.", "error");
        submitButton.disabled = false;
        submitButton.innerHTML = '<i class="fas fa-plus"></i> Add Story';
      }
    };
  }

  async displayDetailPage(storyId) {
    this.cleanupPageResources();
    try {
      const response = await StoryApiSource.getStoryDetail(storyId);
      if (!response.error && response.story) {
        this._mainView.renderPage(
          () => this._detailPageView.render(response.story),
          () => this._setupDetailFeatures(response.story)
        );
      } else {
        this._mainView.showError(response.message || "Failed to fetch story details.");
      }
    } catch (error) {
      console.error("Error fetching story detail:", error);
      if (
        error.message.includes("token") ||
        error.message.includes("logged in")
      ) {
        AuthModel.clearCredentials();
        window.location.hash = "#/login";
        this._mainView.showError("Session expired. Please log in again.");
      } else {
        this._mainView.showError(error.message || "Could not connect to the server.");
      }
    }
  }

  _setupDetailFeatures(story) {
    console.log("Setting up detail page features...");
    if (story.lat && story.lon) {
      const mapContainer = document.getElementById("detailStoryMap");
      if (mapContainer) {
        try {
          console.log("Initializing detail map...");
          const detailMap = MapUtils.initMap("detailStoryMap", {
            center: [story.lat, story.lon],
            zoom: 15,
            scrollWheelZoom: false,
          });
          MapUtils.addMarkers(detailMap, [story]);

          setTimeout(() => {
            if (detailMap) detailMap.invalidateSize();
          }, 150);
        } catch (error) {
          console.error("Failed to initialize detail map:", error);
          mapContainer.innerHTML = `<p>Error loading map: ${error.message}</p>`;
        }
      } else {
        console.warn("#detailStoryMap container not found during setup");
      }
    } else {
      const mapContainerElement = document.getElementById("detailStoryMapContainer");
      if (mapContainerElement) {
        const existingNoLocation = mapContainerElement.querySelector('.no-location-info');
        if (!existingNoLocation) {
          mapContainerElement.innerHTML += '<p class="no-location-info">Location data is not available for this story.</p>';
        }
        const mapDiv = document.getElementById("detailStoryMap");
        if (mapDiv) mapDiv.style.display = 'none';
      }
    }
  }
}

export default StoryPresenter;